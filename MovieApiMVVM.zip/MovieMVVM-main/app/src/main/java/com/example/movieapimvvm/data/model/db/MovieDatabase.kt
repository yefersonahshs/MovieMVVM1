package com.example.movieapimvvm.data.model.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.movieapimvvm.data.model.db.dao.MovieDao

@Database(entities = [MovieDB::class],version = 1)
abstract class MovieDatabase:RoomDatabase() {

    abstract fun getMovieDao():MovieDao


    companion object{
        @Volatile private var instance : MovieDatabase?=null

        fun getDatabase(context: Context): MovieDatabase=
            instance?: synchronized(this) { instance?:buildDatabase(context).also {instance= it }}

        private  fun buildDatabase(context: Context) =
            Room.databaseBuilder(context,MovieDatabase::class.java,"movie_database")
                .allowMainThreadQueries()
                .build()

}
}