package com.example.movieapimvvm.data.model.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.movieapimvvm.data.model.db.MovieDB

@Dao
interface MovieDao {

    @Query("SELECT * FROM  MOVIE_TABLE order by  original_title desc")
    suspend fun geAllMovies():List<MovieDB>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovie(movies:List<MovieDB>)

   @Query("DELETE  FROM  movie_table")
    suspend fun deleteMovies()



}