package com.example.movieapimvvm.domain.entity

import com.example.movieapimvvm.data.model.db.MovieDB
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Movie(
    @SerializedName("adult")
    val adult: Boolean,
    @SerializedName("backdrop_path")
    val backdrop_path: String,
    @SerializedName("id")
    val id: Int,
    @SerializedName("original_language")
    val original_language: String,
    @SerializedName("original_title")
    val original_title: String,
    @SerializedName("overview")
    val overview: String,
    @SerializedName("popularity")
    val popularity: Double,
    @SerializedName("poster_path")
    val poster_path: String,
    @SerializedName("release_date")
    val release_date: String,
    @SerializedName("title")
    val title: String,
    @SerializedName("video")
    val video: Boolean,
    @SerializedName("vote_average")
    val vote_average: Double,
    @SerializedName("vote_count")
    val vote_count: Int
)


fun MovieDB.toDomain()= Movie(adult,backdrop_path,id, original_language, original_title, overview, popularity, poster_path, release_date, title, video, vote_average, vote_count)