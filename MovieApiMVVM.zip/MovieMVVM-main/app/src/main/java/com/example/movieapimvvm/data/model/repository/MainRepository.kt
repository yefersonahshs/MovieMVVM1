package com.example.movieapimvvm.data.model.repository

import com.example.movieapimvvm.domain.entity.Movie
import com.example.movieapimvvm.data.model.MovieDto
import com.example.movieapimvvm.data.model.db.MovieDB
import com.example.movieapimvvm.data.model.db.dao.MovieDao
import com.example.movieapimvvm.domain.MovieService
import com.example.movieapimvvm.domain.entity.toDomain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class MainRepository @Inject constructor(
    private val api: MovieService,
    private val movieDao: MovieDao
) {
    suspend fun fetchMovies(): MutableList<Movie> {
        return withContext(Dispatchers.IO) {
            val movieResponse = api.getMovies()
            val movies = movieResponse.results
            val movieList = parseMovieResult(movies)
            movieList
        }
    }

    suspend fun fetchMoviesFromDatabase(): MutableList<Movie> {
        return withContext(Dispatchers.IO) {
            val movieResponse: List<MovieDB> = movieDao.geAllMovies()

            val movies: List<Movie> = movieResponse.map { it.toDomain() }

            movies as MutableList<Movie>
        }
    }
    suspend fun  insertMovies(movies: List<MovieDB>){
        movieDao.insertMovie(movies)

    }

    suspend fun  clearMovies(){
        movieDao.deleteMovies()

    }



    private fun parseMovieResult(movies: List<MovieDto>): MutableList<Movie> {
        val moviesList = mutableListOf<Movie>()
        for (movie in movies) {

            val adult = movie.adult
            val backdrop_path = movie.backdrop_path
            val id = movie.id
            val original_language = movie.original_language
            val original_title = movie.original_title
            val overview = movie.overview
            val popularity = movie.popularity
            val poster_path = movie.poster_path
            val release_date = movie.release_date
            val title = movie.title
            val video = movie.video
            val vote_average = movie.vote_average
            val vote_count = movie.vote_count

            moviesList.add(Movie(adult, backdrop_path, id, original_language, original_title, overview, popularity, poster_path, release_date, title, video, vote_average, vote_count))
        }
        return moviesList
    }
}