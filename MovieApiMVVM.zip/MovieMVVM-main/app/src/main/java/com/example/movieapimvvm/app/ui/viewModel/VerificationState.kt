package com.example.movieapimvvm.app.ui.viewModel

import com.example.movieapimvvm.domain.entity.Movie

sealed class VerificationState {

    object Loading : VerificationState()
    object EmptyList : VerificationState()
    data class ShowMovies(val moviesList: List<Movie>) : VerificationState()
}