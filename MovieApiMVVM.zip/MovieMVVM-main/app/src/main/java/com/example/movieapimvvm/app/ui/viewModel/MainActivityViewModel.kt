package com.example.movieapimvvm.app.ui.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.movieapimvvm.data.model.repository.MainRepository
import com.example.movieapimvvm.domain.GetMovieUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainActivityViewModel @Inject constructor(
    private val getMovieUseCase: GetMovieUseCase
) : ViewModel() {


    private var _state= MutableLiveData<VerificationState>()

    val state:MutableLiveData<VerificationState>
    get() = _state

    init {
        viewModelScope.launch {
            val result = getMovieUseCase()
            if (!result.isNullOrEmpty()) {
                _state.value = VerificationState.ShowMovies(result)
                  }
                _state.value = VerificationState.EmptyList
            }
        }
    }

    fun showEmpty() {
        println("lista vacia")
    }
