package com.example.movieapimvvm.domain

import com.example.movieapimvvm.data.model.MovieApiInterface
import com.example.movieapimvvm.data.model.MovieResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class MovieService @Inject constructor(
    private val api: MovieApiInterface
) {

    suspend fun getMovies(): MovieResponse {
        return withContext(Dispatchers.IO) {
            val response = api.getAllMovies()
            response
        }

    }

}