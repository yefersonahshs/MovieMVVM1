package com.example.movieapimvvm.app.ui.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.movieapimvvm.app.ui.adapter.MovieAdapter
import com.example.movieapimvvm.databinding.ActivityMainBinding
import com.example.movieapimvvm.app.ui.viewModel.MainActivityViewModel
import com.example.movieapimvvm.app.ui.viewModel.VerificationState
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainActivityViewModel by viewModels()
    private val adapter = MovieAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.recycler.adapter = adapter
        binding.recycler.layoutManager = LinearLayoutManager(this)
        viewModel.state.observe(this, ::stateHandler)
    }

    private fun stateHandler(state: VerificationState) = when (state) {
        is VerificationState.ShowMovies -> adapter.submitList(state.moviesList)
        VerificationState.EmptyList -> print("no")
        VerificationState.Loading -> TODO()
    }
}

