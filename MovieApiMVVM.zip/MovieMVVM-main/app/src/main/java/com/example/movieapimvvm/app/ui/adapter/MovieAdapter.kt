package com.example.movieapimvvm.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.movieapimvvm.databinding.MovieItemListBinding
import com.example.movieapimvvm.domain.entity.Movie

private val TAG= MovieAdapter::class.java.simpleName
class MovieAdapter: ListAdapter<Movie, MovieAdapter.MovieViewHolder>(DiffCallback) {

    companion object DiffCallback: DiffUtil.ItemCallback<Movie>() {
        override fun areContentsTheSame(oldItem: Movie, newItem: Movie): Boolean {
            return oldItem.original_title == newItem.original_title
        }

        override fun areItemsTheSame(oldItem: Movie, newItem: Movie): Boolean {
            return oldItem == newItem
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup,viewType:Int):MovieViewHolder{
        val binding=MovieItemListBinding.inflate(LayoutInflater.from(parent.context))
        return MovieViewHolder(binding)
    }


    override fun  onBindViewHolder(holder:MovieViewHolder,position:Int){
        val movie= getItem(position)
        holder.bind(movie)


    }


    inner class MovieViewHolder(private val binding:MovieItemListBinding):RecyclerView.ViewHolder(binding.root){
        fun bind(movie: Movie){
            binding.nameMovieText.text=movie.original_title.toString()
        }
    }



}
