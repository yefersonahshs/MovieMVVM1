package com.example.movieapimvvm.data.model.di

import android.content.Context
import androidx.room.Room
import com.example.movieapimvvm.data.model.db.MovieDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ActivityContext
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
object RoomModule {


    @Singleton
    @Provides
    fun provideRoom(@ApplicationContext context: Context):MovieDatabase{
        return MovieDatabase.getDatabase(context)
    }


    @Singleton
    @Provides
    fun provideMovieDao(db:MovieDatabase)= db.getMovieDao()




}