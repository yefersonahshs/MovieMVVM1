package com.example.movieapimvvm.domain

import com.example.movieapimvvm.data.model.db.toDatabase
import com.example.movieapimvvm.data.model.repository.MainRepository
import com.example.movieapimvvm.domain.entity.Movie
import javax.inject.Inject

class GetMovieUseCase @Inject constructor(
    private val repository: MainRepository
) {
    suspend operator fun invoke(): List<Movie>{
        val movies= repository.fetchMovies()

        return  if (movies.isNotEmpty()){
            repository.clearMovies()
            repository.insertMovies(movies.map { it.toDatabase() })
            movies
        }else{
            repository.fetchMoviesFromDatabase()
        }

    }
}